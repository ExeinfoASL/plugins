*************************************************
*                                               *
* plugin for Exeinfo Pe / PeiD                  *
*                                               *
*                              wwwHelper v.0.3  *
*                                               *
*                             created by A.S.L  *
*                                               *
* www.exeinfo.xn.pl                             *
*                                               *
* updated : 2022.12.01                          *
*                                               *
*************************************************

 usage : copy file to \plugins directory

 www links to exe unpackers

