========================================================================

	Plugin for VB Decompiler - www.vb-decompiler.org


	v.0.0.0.1


	This program run Exeinfo Pe ( shell option needed in Exeinfo Pe config )


========================================================================

			A.S.L







